Plots made during cruise
